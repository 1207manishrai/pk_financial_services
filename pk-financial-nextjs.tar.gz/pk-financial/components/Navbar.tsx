"use client";
import { useState } from "react";
import Link from "next/link";
const links = [
  {href:"/",label:"Home"},{href:"/#about",label:"About Us"},{href:"/#services",label:"Services"},
  {href:"/#",label:"Mutual Funds"},{href:"/#",label:"Life Insurance"},{href:"/#",label:"Financial Planning"},
  {href:"/#",label:"Downloads"},{href:"/#contact",label:"Contact Us"},
];
export default function Navbar() {
  const [open,setOpen]=useState(false);
  return (
    <nav style={{background:"var(--navy)",position:"relative",zIndex:99}}>
      <div style={{maxWidth:1200,margin:"auto",padding:"0 24px",display:"flex",alignItems:"center",justifyContent:"space-between"}}>
        <ul style={{display:"flex",listStyle:"none",flexWrap:"wrap",margin:0,padding:0}} className={open?"nav-open":""} id="nav-list">
          {links.map(l=>(
            <li key={l.label}><Link href={l.href} onClick={()=>setOpen(false)} style={{display:"block",padding:"14px 13px",color:"rgba(255,255,255,.82)",textDecoration:"none",fontSize:13.5,fontWeight:500}}>{l.label}</Link></li>
          ))}
          <li><Link href="/calculators" onClick={()=>setOpen(false)} style={{display:"block",padding:"8px 16px",margin:"8px 6px",background:"rgba(201,168,76,.2)",color:"var(--gold)",borderRadius:4,textDecoration:"none",fontSize:13,fontWeight:700,border:"1px solid var(--gold)"}}>🧮 Calculators</Link></li>
          <li><a href="#" style={{display:"block",padding:"8px 16px",margin:"8px 4px",background:"var(--gold)",color:"var(--navy)",borderRadius:4,textDecoration:"none",fontSize:13,fontWeight:700}}>Login</a></li>
        </ul>
        <button onClick={()=>setOpen(!open)} style={{display:"none",background:"none",border:"none",cursor:"pointer",padding:8}} className="hbg" aria-label="Menu">
          <span style={{display:"block",width:24,height:2,background:"#fff",margin:"5px 0",borderRadius:2}}/>
          <span style={{display:"block",width:24,height:2,background:"#fff",margin:"5px 0",borderRadius:2}}/>
          <span style={{display:"block",width:24,height:2,background:"#fff",margin:"5px 0",borderRadius:2}}/>
        </button>
      </div>
      <style>{`
        @media(max-width:900px){
          #nav-list{display:none !important;}
          #nav-list.nav-open{display:flex !important;flex-direction:column;position:absolute;top:100%;left:0;right:0;background:var(--navy2);padding:8px 0;}
          .hbg{display:block !important;}
        }
      `}</style>
    </nav>
  );
}
