"use client";
import { useState } from "react";

const WA_NUMBER = "918318442129";

export default function Contact() {
  const [form, setForm] = useState({
    firstName: "", lastName: "", phone: "", email: "", service: "", message: ""
  });
  const [status, setStatus] = useState<"idle" | "loading" | "success">("idle");

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStatus("loading");

    // Build WhatsApp message with all form details
    const msg = [
      `🔔 *New Enquiry – PK Financial Services*`,
      ``,
      `👤 *Name:* ${form.firstName} ${form.lastName}`,
      `📞 *Phone:* ${form.phone}`,
      `✉️ *Email:* ${form.email}`,
      `💼 *Service:* ${form.service}`,
      `📝 *Message:* ${form.message || "Not provided"}`,
      ``,
      `_Sent via pkfinancialservices.in_`
    ].join("\n");

    const encodedMsg = encodeURIComponent(msg);
    const waURL = `https://wa.me/${WA_NUMBER}?text=${encodedMsg}`;

    setTimeout(() => {
      setStatus("success");
      // Open WhatsApp
      window.open(waURL, "_blank");
    }, 600);
  };

  const inp: React.CSSProperties = {
    width: "100%", padding: "11px 14px",
    border: "1.5px solid #ddd6ca", borderRadius: 7,
    fontSize: 14, color: "#1e293b", background: "#fff",
    outline: "none", fontFamily: "inherit",
  };
  const lbl: React.CSSProperties = {
    display: "block", fontSize: 12, fontWeight: 600,
    color: "var(--navy)", textTransform: "uppercase",
    letterSpacing: ".5px", marginBottom: 6,
  };

  return (
    <section id="contact" style={{ background: "#fff", padding: "80px 24px" }}>
      <div style={{ maxWidth: 1200, margin: "auto" }}>

        {/* Section Title */}
        <div style={{ textAlign: "center", marginBottom: 50 }}>
          <div style={{ fontSize: 12, fontWeight: 600, letterSpacing: 2, textTransform: "uppercase", color: "var(--gold)", marginBottom: 10 }}>Reach Out</div>
          <h2 style={{ fontFamily: "'Playfair Display',serif", fontSize: "clamp(28px,3.5vw,40px)", fontWeight: 700, color: "var(--navy)" }}>
            Get In Touch With <span style={{ color: "var(--gold)" }}>Us</span>
          </h2>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1.1fr", gap: 60, alignItems: "start" }} className="contact-grid">

          {/* LEFT — Contact Info */}
          <div>
            <h3 style={{ fontFamily: "'Playfair Display',serif", fontSize: 24, color: "var(--navy)", marginBottom: 18 }}>
              We&apos;d Love to Hear From You
            </h3>
            <p style={{ color: "var(--gray)", lineHeight: 1.8, marginBottom: 28 }}>
              Fill the form and your enquiry will be sent directly to our WhatsApp instantly. We&apos;ll get back to you within a few hours.
            </p>

            {[
              { ico: "📍", label: "Address", val: "Sector-16A/232, Vrindavan Yojna-4, Raebareli Road, Lucknow - 226029" },
              { ico: "📞", label: "Phone", val: <><a href="tel:+918318442129" style={{ color: "inherit", textDecoration: "none" }}>+91 83184 42129</a> &nbsp;|&nbsp; <a href="tel:+919936408150" style={{ color: "inherit", textDecoration: "none" }}>+91 99364 08150</a></> },
              { ico: "✉️", label: "Email", val: <a href="mailto:pkfinance11@gmail.com" style={{ color: "inherit", textDecoration: "none" }}>pkfinance11@gmail.com</a> },
              { ico: "⏰", label: "Working Hours", val: "Mon–Sat: 9:00 AM – 6:00 PM" },
            ].map((item, i) => (
              <div key={i} style={{ display: "flex", alignItems: "flex-start", gap: 14, marginBottom: 20 }}>
                <div style={{ width: 42, height: 42, background: "var(--light)", borderRadius: 8, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18, flexShrink: 0 }}>{item.ico}</div>
                <div>
                  <div style={{ fontSize: 11, textTransform: "uppercase", letterSpacing: 1, color: "var(--gray)" }}>{item.label}</div>
                  <div style={{ fontSize: 15, fontWeight: 600, color: "var(--navy)" }}>{item.val}</div>
                </div>
              </div>
            ))}

            {/* Direct WhatsApp Button */}
            <a
              href={`https://wa.me/${WA_NUMBER}?text=${encodeURIComponent("Hello PK Financial Services, I would like to know more about your services.")}`}
              target="_blank" rel="noreferrer"
              style={{ display: "inline-flex", alignItems: "center", gap: 10, background: "#25D366", color: "#fff", padding: "13px 24px", borderRadius: 8, textDecoration: "none", fontWeight: 700, fontSize: 14, marginTop: 8 }}>
              <WAIcon /> Chat Directly on WhatsApp
            </a>
          </div>

          {/* RIGHT — Form */}
          <div style={{ background: "var(--cream)", borderRadius: 16, padding: 36 }}>
            <h3 style={{ fontFamily: "'Playfair Display',serif", fontSize: 22, color: "var(--navy)", marginBottom: 4 }}>Send Us a Message</h3>
            <p style={{ fontSize: 13, color: "var(--gray)", marginBottom: 24, display: "flex", alignItems: "center", gap: 6 }}>
              <span>📲</span> Enquiry goes straight to our WhatsApp
            </p>

            {status === "success" ? (
              /* Success State */
              <div style={{ textAlign: "center", padding: "50px 20px" }}>
                <div style={{ fontSize: 64, marginBottom: 16 }}>✅</div>
                <h4 style={{ fontFamily: "'Playfair Display',serif", fontSize: 24, color: "var(--navy)", marginBottom: 10 }}>
                  Enquiry Sent!
                </h4>
                <p style={{ color: "var(--gray)", marginBottom: 6 }}>WhatsApp has opened with your enquiry.</p>
                <p style={{ color: "var(--gray)", fontSize: 13, marginBottom: 8 }}>
                  Just press <strong>Send</strong> in WhatsApp to confirm.
                </p>
                <p style={{ color: "var(--gray)", fontSize: 13, marginBottom: 24 }}>
                  We will contact you within a few hours.
                </p>
                <button
                  onClick={() => { setStatus("idle"); setForm({ firstName:"", lastName:"", phone:"", email:"", service:"", message:"" }); }}
                  style={{ background: "var(--navy)", color: "#fff", border: "none", padding: "12px 30px", borderRadius: 8, cursor: "pointer", fontWeight: 600, fontFamily: "inherit", fontSize: 14 }}>
                  Submit Another Enquiry
                </button>
              </div>
            ) : (
              /* Form */
              <form onSubmit={handleSubmit}>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginBottom: 14 }}>
                  <div>
                    <label style={lbl}>First Name *</label>
                    <input name="firstName" value={form.firstName} onChange={handleChange} required placeholder="Ravi" style={inp} />
                  </div>
                  <div>
                    <label style={lbl}>Last Name *</label>
                    <input name="lastName" value={form.lastName} onChange={handleChange} required placeholder="Kumar" style={inp} />
                  </div>
                </div>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginBottom: 14 }}>
                  <div>
                    <label style={lbl}>Phone *</label>
                    <input name="phone" value={form.phone} onChange={handleChange} required type="tel" placeholder="+91 98765 43210" style={inp} />
                  </div>
                  <div>
                    <label style={lbl}>Email *</label>
                    <input name="email" value={form.email} onChange={handleChange} required type="email" placeholder="ravi@email.com" style={inp} />
                  </div>
                </div>
                <div style={{ marginBottom: 14 }}>
                  <label style={lbl}>Service Interested In *</label>
                  <select name="service" value={form.service} onChange={handleChange} required style={inp}>
                    <option value="">-- Select a Service --</option>
                    {["Mutual Fund Investment", "Life / Health Insurance", "Retirement Planning", "Education Planning", "Tax Saving (ELSS)", "Financial Planning"].map(o => (
                      <option key={o}>{o}</option>
                    ))}
                  </select>
                </div>
                <div style={{ marginBottom: 22 }}>
                  <label style={lbl}>Message (Optional)</label>
                  <textarea name="message" value={form.message} onChange={handleChange}
                    placeholder="Tell us about your financial goals..."
                    rows={4} style={{ ...inp, resize: "vertical" }} />
                </div>

                <button
                  type="submit"
                  disabled={status === "loading"}
                  style={{
                    width: "100%", padding: "15px",
                    background: status === "loading" ? "#aaa" : "#25D366",
                    color: "#fff", border: "none", borderRadius: 8,
                    fontSize: 16, fontWeight: 700,
                    cursor: status === "loading" ? "not-allowed" : "pointer",
                    fontFamily: "inherit",
                    display: "flex", alignItems: "center", justifyContent: "center", gap: 10,
                    transition: "background .2s, transform .15s",
                  }}
                  onMouseEnter={e => { if (status !== "loading") (e.currentTarget as HTMLElement).style.transform = "translateY(-1px)"; }}
                  onMouseLeave={e => { (e.currentTarget as HTMLElement).style.transform = ""; }}
                >
                  {status === "loading" ? (
                    <><Spinner /> Opening WhatsApp...</>
                  ) : (
                    <><WAIcon /> Send Enquiry on WhatsApp</>
                  )}
                </button>

                <p style={{ textAlign: "center", fontSize: 12, color: "var(--gray)", marginTop: 12 }}>
                  🔒 Your details are safe and only sent to us via WhatsApp
                </p>
              </form>
            )}
          </div>
        </div>
      </div>

      <style>{`
        @media(max-width:900px){ .contact-grid{ grid-template-columns:1fr !important; } }
        @keyframes spin { to { transform: rotate(360deg); } }
        input:focus, select:focus, textarea:focus { border-color: var(--gold) !important; box-shadow: 0 0 0 3px rgba(201,168,76,.15); }
      `}</style>
    </section>
  );
}

function WAIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="white" style={{ flexShrink: 0 }}>
      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/>
      <path d="M12 0C5.373 0 0 5.373 0 12c0 2.117.554 4.103 1.523 5.824L.057 23.5l5.835-1.53A11.945 11.945 0 0012 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 21.9a9.9 9.9 0 01-5.031-1.37l-.361-.214-3.735.979.997-3.645-.235-.374A9.86 9.86 0 012.1 12c0-5.464 4.436-9.9 9.9-9.9 5.464 0 9.9 4.436 9.9 9.9 0 5.464-4.436 9.9-9.9 9.9z"/>
    </svg>
  );
}

function Spinner() {
  return (
    <span style={{ width: 18, height: 18, border: "2px solid rgba(255,255,255,.4)", borderTopColor: "#fff", borderRadius: "50%", display: "inline-block", animation: "spin 0.8s linear infinite" }} />
  );
}
