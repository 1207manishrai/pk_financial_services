"use client";
import Link from "next/link";
export default function Header() {
  return (
    <header style={{background:"#fff",boxShadow:"0 2px 20px rgba(0,0,0,.08)",position:"sticky",top:0,zIndex:100}}>
      <div style={{maxWidth:1200,margin:"auto",padding:"0 24px",display:"flex",alignItems:"center",justifyContent:"space-between",gap:20,flexWrap:"wrap"}}>
        <Link href="/" style={{display:"flex",alignItems:"center",gap:12,textDecoration:"none",padding:"14px 0"}}>
          <div style={{width:48,height:48,background:"linear-gradient(135deg,var(--navy),var(--navy2))",borderRadius:10,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
            <svg width="28" height="28" viewBox="0 0 28 28" fill="none"><path d="M4 22L10 14L14 18L18 10L24 22H4Z" fill="#c9a84c"/><circle cx="20" cy="7" r="3" fill="#e8c975"/></svg>
          </div>
          <div>
            <div style={{fontFamily:"'Playfair Display',serif",fontSize:20,fontWeight:700,color:"var(--navy)",lineHeight:1.2}}>PK Financial Services</div>
            <div style={{fontSize:10,color:"var(--gold)",letterSpacing:"1.5px",textTransform:"uppercase",fontWeight:600}}>Your Trusted Financial Partner</div>
          </div>
        </Link>
        <div style={{display:"flex",gap:20,flexWrap:"wrap"}}>
          <div style={{display:"flex",alignItems:"center",gap:8}}>
            <div style={{width:36,height:36,background:"var(--light)",borderRadius:8,display:"flex",alignItems:"center",justifyContent:"center",fontSize:16}}>📞</div>
            <div>
              <div style={{fontSize:10,color:"var(--gray)",textTransform:"uppercase",letterSpacing:".8px"}}>Call Us</div>
              <div style={{fontSize:13,fontWeight:600,color:"var(--navy)"}}>
                <a href="tel:+918318442129" style={{color:"inherit",textDecoration:"none"}}>+91 83184 42129</a> / <a href="tel:+919936408150" style={{color:"inherit",textDecoration:"none"}}>99364 08150</a>
              </div>
            </div>
          </div>
          <div style={{display:"flex",alignItems:"center",gap:8}}>
            <div style={{width:36,height:36,background:"var(--light)",borderRadius:8,display:"flex",alignItems:"center",justifyContent:"center",fontSize:16}}>✉️</div>
            <div>
              <div style={{fontSize:10,color:"var(--gray)",textTransform:"uppercase",letterSpacing:".8px"}}>Email Us</div>
              <div style={{fontSize:13,fontWeight:600,color:"var(--navy)"}}><a href="mailto:pkfinance11@gmail.com" style={{color:"inherit",textDecoration:"none"}}>pkfinance11@gmail.com</a></div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
