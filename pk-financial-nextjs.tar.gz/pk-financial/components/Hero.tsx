"use client";
import Link from "next/link";
export default function Hero() {
  return (
    <section style={{background:"linear-gradient(135deg,var(--navy) 0%,#1a3560 60%,#243b6e 100%)",minHeight:520,display:"flex",alignItems:"center",padding:"60px 24px",position:"relative",overflow:"hidden"}}>
      <div style={{position:"absolute",inset:0,backgroundImage:"url(\"data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%23ffffff' fill-opacity='0.03'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/svg%3E\")"}}/>
      <div style={{maxWidth:1200,margin:"auto",width:"100%",display:"grid",gridTemplateColumns:"1fr 340px",gap:30,alignItems:"center",position:"relative"}} className="hero-grid">
        <div>
          <h1 style={{fontFamily:"'Playfair Display',serif",fontSize:"clamp(32px,4.5vw,54px)",fontWeight:700,color:"#fff",lineHeight:1.18,marginBottom:18}}>
            Your <span style={{color:"var(--gold)"}}>Financial Goals</span>,<br/>Our Expertise
          </h1>
          <p style={{color:"rgba(255,255,255,.72)",fontSize:16,lineHeight:1.7,maxWidth:520,marginBottom:34}}>PK Financial Services helps you build, grow and protect your wealth with expert guidance in Mutual Funds, Insurance, Tax Planning, and more.</p>
          <div style={{display:"flex",gap:14,flexWrap:"wrap"}}>
            <a href="#contact" style={{background:"var(--gold)",color:"var(--navy)",padding:"13px 28px",borderRadius:5,fontSize:14,fontWeight:700,textDecoration:"none"}}>Get Free Consultation →</a>
            <a href="#services" style={{border:"2px solid rgba(255,255,255,.35)",color:"#fff",padding:"13px 28px",borderRadius:5,fontSize:14,fontWeight:600,textDecoration:"none"}}>Our Services</a>
            <Link href="/calculators" style={{border:"2px solid var(--gold)",color:"var(--gold)",padding:"13px 28px",borderRadius:5,fontSize:14,fontWeight:600,textDecoration:"none"}}>🧮 Calculators</Link>
          </div>
        </div>
        <div style={{display:"flex",flexDirection:"column",gap:14}} className="hero-cards">
          {[{icon:"📈",t:"Mutual Fund Investments",d:"SIP, lump sum, or portfolio rebalancing — we guide every step."},{icon:"🛡️",t:"Life & Health Insurance",d:"Protect what matters most with the right coverage plan."},{icon:"💰",t:"Tax Saving Solutions",d:"Maximize returns and minimise your tax outgo legally."}].map(c=>(
            <a key={c.t} href="#services" style={{background:"rgba(255,255,255,.07)",border:"1px solid rgba(255,255,255,.12)",borderRadius:12,padding:20,textDecoration:"none",display:"block"}}>
              <h4 style={{color:"#fff",fontSize:14,fontWeight:600,marginBottom:4}}>{c.icon} {c.t}</h4>
              <p style={{color:"rgba(255,255,255,.55)",fontSize:12,lineHeight:1.5,margin:0}}>{c.d}</p>
            </a>
          ))}
        </div>
      </div>
      <style>{`@media(max-width:900px){.hero-grid{grid-template-columns:1fr !important;}.hero-cards{display:none !important;}}`}</style>
    </section>
  );
}
