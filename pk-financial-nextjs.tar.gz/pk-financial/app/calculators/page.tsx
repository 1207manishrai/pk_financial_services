"use client";
import { useState, useEffect, useRef } from "react";
import Link from "next/link";

function fmt(n: number): string {
  if (n >= 10000000) return "₹" + (n / 10000000).toFixed(2) + " Cr";
  if (n >= 100000) return "₹" + (n / 100000).toFixed(2) + " L";
  return "₹" + Math.round(n).toLocaleString("en-IN");
}

function RangeField({ label, id, min, max, step, value, onChange, displayVal, minLabel, maxLabel }: {
  label: string; id: string; min: number; max: number; step: number; value: number;
  onChange: (v: number) => void; displayVal: string; minLabel: string; maxLabel: string;
}) {
  const pct = ((value - min) / (max - min)) * 100;
  return (
    <div style={{ marginBottom: 24 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", fontSize: 13, fontWeight: 600, color: "var(--navy)", marginBottom: 8, textTransform: "uppercase", letterSpacing: ".5px" }}>
        <label htmlFor={id}>{label}</label>
        <span style={{ fontFamily: "'Playfair Display',serif", fontSize: 16, color: "var(--gold)", textTransform: "none", letterSpacing: 0 }}>{displayVal}</span>
      </div>
      <input id={id} type="range" min={min} max={max} step={step} value={value}
        onChange={e => onChange(+e.target.value)}
        style={{ "--range-val": pct + "%" } as React.CSSProperties} />
      <div style={{ display: "flex", justifyContent: "space-between", fontSize: 11, color: "var(--gray)", marginTop: 4 }}>
        <span>{minLabel}</span><span>{maxLabel}</span>
      </div>
    </div>
  );
}

function Donut({ pct, label }: { pct: number; label: string }) {
  const circ = 345;
  const offset = circ - (Math.min(pct, 100) / 100) * circ;
  return (
    <div style={{ margin: "16px auto", position: "relative", width: 140, height: 140 }}>
      <svg width="140" height="140" viewBox="0 0 140 140" style={{ transform: "rotate(-90deg)" }}>
        <circle cx="70" cy="70" r="55" fill="none" stroke="rgba(255,255,255,.1)" strokeWidth="16" />
        <circle cx="70" cy="70" r="55" fill="none" stroke="var(--gold)" strokeWidth="16"
          strokeDasharray={circ} strokeDashoffset={offset} strokeLinecap="round"
          style={{ transition: "stroke-dashoffset .6s ease" }} />
      </svg>
      <div style={{ position: "absolute", inset: 0, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center" }}>
        <div style={{ fontFamily: "'Playfair Display',serif", fontSize: 22, color: "var(--gold)", fontWeight: 700 }}>{Math.round(pct)}%</div>
        <div style={{ fontSize: 10, color: "rgba(255,255,255,.5)" }}>{label}</div>
      </div>
    </div>
  );
}

function ResultPill({ label, val, valStyle }: { label: string; val: string; valStyle?: React.CSSProperties }) {
  return (
    <div style={{ background: "rgba(255,255,255,.08)", border: "1px solid rgba(255,255,255,.12)", borderRadius: 10, padding: "12px 16px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
      <span style={{ fontSize: 12, color: "rgba(255,255,255,.6)" }}>{label}</span>
      <span style={{ fontSize: 15, fontWeight: 700, color: "#fff", ...valStyle }}>{val}</span>
    </div>
  );
}

function CalcLayout({ title, subtitle, inputs, result }: { title: string; subtitle: string; inputs: React.ReactNode; result: React.ReactNode }) {
  return (
    <div style={{ background: "#fff", borderRadius: 16, boxShadow: "0 4px 24px rgba(0,0,0,.07)", overflow: "hidden" }}>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr" }} className="calc-grid">
        <div style={{ padding: 36, borderRight: "1px solid #eee" }}>
          <h2 style={{ fontFamily: "'Playfair Display',serif", fontSize: 22, color: "var(--navy)", marginBottom: 6 }}>{title}</h2>
          <p style={{ fontSize: 13, color: "var(--gray)", marginBottom: 28 }}>{subtitle}</p>
          {inputs}
        </div>
        <div style={{ padding: 36, background: "linear-gradient(160deg,var(--navy) 0%,#1a3560 100%)", display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "center", textAlign: "center" }}>
          {result}
        </div>
      </div>
      <style>{`@media(max-width:700px){.calc-grid{grid-template-columns:1fr !important;}}`}</style>
    </div>
  );
}

function SIPCalc() {
  const [amt, setAmt] = useState(5000), [rate, setRate] = useState(12), [years, setYears] = useState(10);
  const r = rate / 100 / 12, n = years * 12;
  const total = amt * (((Math.pow(1 + r, n) - 1) / r) * (1 + r));
  const invested = amt * n, returns = total - invested, gainPct = (returns / invested) * 100;
  return <CalcLayout title="SIP Calculator" subtitle="Estimate returns on your monthly SIP investments"
    inputs={<>
      <RangeField label="Monthly Investment" id="sip-amt" min={500} max={100000} step={500} value={amt} onChange={setAmt} displayVal={fmt(amt)} minLabel="₹500" maxLabel="₹1,00,000" />
      <RangeField label="Expected Annual Return" id="sip-rate" min={1} max={30} step={0.5} value={rate} onChange={setRate} displayVal={rate.toFixed(1) + "%"} minLabel="1%" maxLabel="30%" />
      <RangeField label="Investment Period" id="sip-years" min={1} max={40} step={1} value={years} onChange={setYears} displayVal={years + " Yrs"} minLabel="1 Yr" maxLabel="40 Yrs" />
    </>}
    result={<>
      <div style={{ fontSize: 12, textTransform: "uppercase", letterSpacing: 1.5, color: "rgba(255,255,255,.5)", marginBottom: 6 }}>Total Value at Maturity</div>
      <div style={{ fontFamily: "'Playfair Display',serif", fontSize: 36, fontWeight: 700, color: "var(--gold)", marginBottom: 12 }}>{fmt(total)}</div>
      <Donut pct={Math.min(gainPct / 3, 100)} label="Gain" />
      <div style={{ display: "flex", flexDirection: "column", gap: 10, width: "100%" }}>
        <ResultPill label="Total Invested" val={fmt(invested)} />
        <ResultPill label="Est. Returns" val={fmt(returns)} valStyle={{ color: "var(--gold2)" }} />
      </div>
    </>}
  />;
}

function LumpsumCalc() {
  const [amt, setAmt] = useState(100000), [rate, setRate] = useState(12), [years, setYears] = useState(10);
  const total = amt * Math.pow(1 + rate / 100, years);
  const returns = total - amt, gainPct = (returns / amt) * 100;
  return <CalcLayout title="Lumpsum Calculator" subtitle="Calculate the future value of a one-time investment"
    inputs={<>
      <RangeField label="One-Time Investment" id="ls-amt" min={1000} max={10000000} step={1000} value={amt} onChange={setAmt} displayVal={fmt(amt)} minLabel="₹1,000" maxLabel="₹1 Cr" />
      <RangeField label="Expected Annual Return" id="ls-rate" min={1} max={30} step={0.5} value={rate} onChange={setRate} displayVal={rate.toFixed(1) + "%"} minLabel="1%" maxLabel="30%" />
      <RangeField label="Investment Period" id="ls-years" min={1} max={40} step={1} value={years} onChange={setYears} displayVal={years + " Yrs"} minLabel="1 Yr" maxLabel="40 Yrs" />
    </>}
    result={<>
      <div style={{ fontSize: 12, textTransform: "uppercase", letterSpacing: 1.5, color: "rgba(255,255,255,.5)", marginBottom: 6 }}>Total Value at Maturity</div>
      <div style={{ fontFamily: "'Playfair Display',serif", fontSize: 36, fontWeight: 700, color: "var(--gold)", marginBottom: 12 }}>{fmt(total)}</div>
      <Donut pct={Math.min(gainPct / 5, 100)} label="Gain" />
      <div style={{ display: "flex", flexDirection: "column", gap: 10, width: "100%" }}>
        <ResultPill label="Amount Invested" val={fmt(amt)} />
        <ResultPill label="Est. Returns" val={fmt(returns)} valStyle={{ color: "var(--gold2)" }} />
      </div>
    </>}
  />;
}

function LoanCalc() {
  const [principal, setPrincipal] = useState(1000000), [rate, setRate] = useState(8.5), [years, setYears] = useState(20);
  const r = rate / 100 / 12, n = years * 12;
  const emi = principal * r * Math.pow(1 + r, n) / (Math.pow(1 + r, n) - 1);
  const totalPay = emi * n, interest = totalPay - principal, intPct = (interest / totalPay) * 100;
  return <CalcLayout title="Loan / EMI Calculator" subtitle="Calculate your monthly EMI for any loan"
    inputs={<>
      <RangeField label="Loan Amount" id="loan-amt" min={10000} max={10000000} step={10000} value={principal} onChange={setPrincipal} displayVal={fmt(principal)} minLabel="₹10,000" maxLabel="₹1 Cr" />
      <RangeField label="Annual Interest Rate" id="loan-rate" min={1} max={24} step={0.1} value={rate} onChange={setRate} displayVal={rate.toFixed(1) + "%"} minLabel="1%" maxLabel="24%" />
      <RangeField label="Loan Tenure" id="loan-years" min={1} max={30} step={1} value={years} onChange={setYears} displayVal={years + " Yrs"} minLabel="1 Yr" maxLabel="30 Yrs" />
    </>}
    result={<>
      <div style={{ fontSize: 12, textTransform: "uppercase", letterSpacing: 1.5, color: "rgba(255,255,255,.5)", marginBottom: 6 }}>Monthly EMI</div>
      <div style={{ fontFamily: "'Playfair Display',serif", fontSize: 36, fontWeight: 700, color: "var(--gold)", marginBottom: 12 }}>{fmt(emi)}</div>
      <Donut pct={intPct} label="Interest" />
      <div style={{ display: "flex", flexDirection: "column", gap: 10, width: "100%" }}>
        <ResultPill label="Total Payment" val={fmt(totalPay)} />
        <ResultPill label="Total Interest" val={fmt(interest)} valStyle={{ color: "#ff9a9a" }} />
        <ResultPill label="Principal" val={fmt(principal)} />
      </div>
    </>}
  />;
}

const TABS = [
  { id: "sip", icon: "📈", label: "SIP Calculator" },
  { id: "lumpsum", icon: "💰", label: "Lumpsum Calculator" },
  { id: "loan", icon: "🏦", label: "Loan / EMI" },
];

export default function CalculatorsPage() {
  const [active, setActive] = useState("sip");
  useEffect(() => {
    const hash = window.location.hash.replace("#", "");
    if (["lumpsum", "loan"].includes(hash)) setActive(hash);
  }, []);

  return (
    <>
      <div style={{ background: "var(--navy)", color: "#a0aec0", fontSize: 12, padding: "7px 24px", display: "flex", justifyContent: "space-between", flexWrap: "wrap", gap: 6 }}>
        <span>⏰ Mon–Sat: 09:00 – 18:00 &nbsp;|&nbsp; 📞 <a href="tel:+918318442129" style={{ color: "#a0aec0" }}>8318442129</a> &nbsp;/&nbsp; <a href="tel:+919936408150" style={{ color: "#a0aec0" }}>9936408150</a></span>
        <Link href="/" style={{ color: "var(--gold)", textDecoration: "none", fontWeight: 600 }}>← Back to Home</Link>
      </div>
      <header style={{ background: "#fff", boxShadow: "0 2px 20px rgba(0,0,0,.08)" }}>
        <div style={{ maxWidth: 1200, margin: "auto", padding: "0 24px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <Link href="/" style={{ display: "flex", alignItems: "center", gap: 12, textDecoration: "none", padding: "14px 0" }}>
            <div style={{ width: 48, height: 48, background: "linear-gradient(135deg,var(--navy),var(--navy2))", borderRadius: 10, display: "flex", alignItems: "center", justifyContent: "center" }}>
              <svg width="28" height="28" viewBox="0 0 28 28" fill="none"><path d="M4 22L10 14L14 18L18 10L24 22H4Z" fill="#c9a84c" /><circle cx="20" cy="7" r="3" fill="#e8c975" /></svg>
            </div>
            <div>
              <div style={{ fontFamily: "'Playfair Display',serif", fontSize: 20, fontWeight: 700, color: "var(--navy)" }}>PK Financial Services</div>
              <div style={{ fontSize: 10, color: "var(--gold)", letterSpacing: "1.5px", textTransform: "uppercase", fontWeight: 600 }}>Your Trusted Financial Partner</div>
            </div>
          </Link>
          <Link href="/" style={{ background: "var(--navy)", color: "#fff", padding: "9px 20px", borderRadius: 5, textDecoration: "none", fontSize: 13, fontWeight: 600 }}>← Back to Home</Link>
        </div>
      </header>
      <div style={{ background: "linear-gradient(135deg,var(--navy),#1a3560)", padding: "50px 24px", textAlign: "center" }}>
        <h1 style={{ fontFamily: "'Playfair Display',serif", fontSize: "clamp(28px,4vw,42px)", color: "#fff", marginBottom: 10 }}>Financial <span style={{ color: "var(--gold)" }}>Calculators</span></h1>
        <p style={{ color: "rgba(255,255,255,.7)", fontSize: 15 }}>Plan your investments and loans smartly with our free tools</p>
      </div>
      <div style={{ maxWidth: 900, margin: "-24px auto 0", padding: "0 24px", position: "relative", zIndex: 10 }}>
        <div style={{ display: "flex", background: "#fff", borderRadius: 12, boxShadow: "0 8px 30px rgba(0,0,0,.12)", overflow: "hidden" }}>
          {TABS.map(tab => (
            <button key={tab.id} onClick={() => setActive(tab.id)}
              style={{ flex: 1, padding: "18px 10px", border: "none", background: active === tab.id ? "var(--light)" : "none", cursor: "pointer", fontFamily: "inherit", fontSize: 14, fontWeight: 600, color: active === tab.id ? "var(--navy)" : "var(--gray)", display: "flex", flexDirection: "column", alignItems: "center", gap: 4, borderBottom: active === tab.id ? "3px solid var(--gold)" : "3px solid transparent", transition: "all .2s" }}>
              <span style={{ fontSize: 22 }}>{tab.icon}</span>{tab.label}
            </button>
          ))}
        </div>
      </div>
      <div style={{ maxWidth: 900, margin: "0 auto", padding: "30px 24px 60px" }}>
        {active === "sip" && <SIPCalc />}
        {active === "lumpsum" && <LumpsumCalc />}
        {active === "loan" && <LoanCalc />}
      </div>
      <div style={{ background: "var(--navy)", color: "rgba(255,255,255,.5)", textAlign: "center", padding: 18, fontSize: 12.5 }}>
        © 2026 <Link href="/" style={{ color: "var(--gold)", textDecoration: "none" }}>PK Financial Services</Link> | Lucknow - 226029 | <a href="tel:+918318442129" style={{ color: "var(--gold)", textDecoration: "none" }}>8318442129</a>
      </div>
    </>
  );
}
