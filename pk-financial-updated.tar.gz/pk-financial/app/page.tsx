import TopBar from "@/components/TopBar";
import Header from "@/components/Header";
import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import Stats from "@/components/Stats";
import CalcStrip from "@/components/CalcStrip";
import About from "@/components/About";
import Services from "@/components/Services";
import Testimonials from "@/components/Testimonials";
import Contact from "@/components/Contact";
import News from "@/components/News";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <>
      <TopBar />
      <Header />
      <Navbar />
      <Hero />
      <Stats />
      <CalcStrip />
      <About />
      <Services />
      {/* Quote Banner */}
      <div style={{ background: "linear-gradient(135deg,var(--navy) 0%,#1a3560 100%)", padding: "60px 24px", textAlign: "center" }}>
        <h2 style={{ fontFamily: "var(--font-playfair,serif)", fontSize: "clamp(24px,3vw,36px)", color: "#fff", marginBottom: 22 }}>
          Get One Personalised <span style={{ color: "var(--gold)" }}>Financial Plan</span> for Yourself
        </h2>
        <a href="#contact" style={{ background: "var(--gold)", color: "var(--navy)", padding: "13px 28px", borderRadius: 5, fontSize: 14, fontWeight: 700, textDecoration: "none", display: "inline-block" }}>Get a Free Quote →</a>
      </div>
      <Testimonials />
      <Contact />
      <News />
      <Footer />
    </>
  );
}
