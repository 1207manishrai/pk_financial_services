"use client";
import { useState } from "react";

export default function Contact() {
  const [submitted, setSubmitted] = useState(false);
  return (
    <section id="contact" style={{ background: "#fff", padding: "80px 24px" }}>
      <div style={{ maxWidth: 1200, margin: "auto" }}>
        <div style={{ textAlign: "center", marginBottom: 50 }}>
          <div style={{ fontSize: 12, fontWeight: 600, letterSpacing: 2, textTransform: "uppercase", color: "var(--gold)", marginBottom: 10 }}>Reach Out</div>
          <h2 style={{ fontFamily: "var(--font-playfair,serif)", fontSize: "clamp(28px,3.5vw,40px)", fontWeight: 700, color: "var(--navy)" }}>Get In Touch With <span style={{ color: "var(--gold)" }}>Us</span></h2>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1.1fr", gap: 60, alignItems: "start" }} className="contact-grid">
          <div>
            <h3 style={{ fontFamily: "var(--font-playfair,serif)", fontSize: 24, color: "var(--navy)", marginBottom: 18 }}>We&apos;d Love to Hear From You</h3>
            <p style={{ color: "var(--gray)", lineHeight: 1.8, marginBottom: 28 }}>Whether you&apos;re just starting your investment journey or want to review your existing portfolio, our expert advisors are here to help.</p>
            {[
              { ico: "📍", label: "Address", val: "Sector-16A/232, Vrindavan Yojna-4, Raebareli Road, Lucknow - 226029" },
              { ico: "📞", label: "Phone", val: <><a href="tel:+918318442129" style={{ color: "inherit", textDecoration: "none" }}>+91 83184 42129</a> | <a href="tel:+919936408150" style={{ color: "inherit", textDecoration: "none" }}>+91 99364 08150</a></> },
              { ico: "✉️", label: "Email", val: <a href="mailto:pkfinance11@gmail.com" style={{ color: "inherit", textDecoration: "none" }}>pkfinance11@gmail.com</a> },
              { ico: "⏰", label: "Working Hours", val: "Mon–Sat: 9:00 AM – 6:00 PM" },
            ].map((item) => (
              <div key={item.label} style={{ display: "flex", alignItems: "flex-start", gap: 14, marginBottom: 20 }}>
                <div style={{ width: 42, height: 42, background: "var(--light)", borderRadius: 8, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18, flexShrink: 0 }}>{item.ico}</div>
                <div>
                  <div style={{ fontSize: 11, textTransform: "uppercase", letterSpacing: 1, color: "var(--gray)" }}>{item.label}</div>
                  <div style={{ fontSize: 15, fontWeight: 600, color: "var(--navy)" }}>{item.val}</div>
                </div>
              </div>
            ))}
          </div>
          <div style={{ background: "var(--cream)", borderRadius: 16, padding: 36 }}>
            <h3 style={{ fontFamily: "var(--font-playfair,serif)", fontSize: 22, color: "var(--navy)", marginBottom: 24 }}>Send Us a Message</h3>
            {submitted ? (
              <div style={{ textAlign: "center", padding: "40px 0" }}>
                <div style={{ fontSize: 48, marginBottom: 16 }}>✅</div>
                <h4 style={{ color: "var(--navy)", fontFamily: "var(--font-playfair,serif)", fontSize: 20, marginBottom: 8 }}>Thank You!</h4>
                <p style={{ color: "var(--gray)" }}>We will contact you shortly.</p>
                <button onClick={() => setSubmitted(false)} style={{ marginTop: 20, background: "var(--navy)", color: "#fff", border: "none", padding: "10px 24px", borderRadius: 7, cursor: "pointer", fontWeight: 600 }}>Send Another</button>
              </div>
            ) : (
              <form onSubmit={e => { e.preventDefault(); setSubmitted(true); }}>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginBottom: 16 }}>
                  <Field label="First Name" placeholder="Ravi" />
                  <Field label="Last Name" placeholder="Kumar" />
                </div>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginBottom: 16 }}>
                  <Field label="Phone" placeholder="+91 98765 43210" type="tel" />
                  <Field label="Email" placeholder="ravi@email.com" type="email" />
                </div>
                <div style={{ marginBottom: 16 }}>
                  <label style={{ display: "block", fontSize: 12, fontWeight: 600, color: "var(--navy)", textTransform: "uppercase", letterSpacing: .5, marginBottom: 6 }}>Service Interested In</label>
                  <select required style={{ width: "100%", padding: "11px 14px", border: "1.5px solid #ddd6ca", borderRadius: 7, fontSize: 14, color: "#1e293b", background: "#fff", outline: "none", fontFamily: "inherit" }}>
                    <option value="">Select a Service</option>
                    {["Mutual Fund Investment","Life / Health Insurance","Retirement Planning","Education Planning","Tax Saving","Financial Planning"].map(o => <option key={o}>{o}</option>)}
                  </select>
                </div>
                <div style={{ marginBottom: 16 }}>
                  <label style={{ display: "block", fontSize: 12, fontWeight: 600, color: "var(--navy)", textTransform: "uppercase", letterSpacing: .5, marginBottom: 6 }}>Message</label>
                  <textarea placeholder="Tell us about your financial goals..." style={{ width: "100%", padding: "11px 14px", border: "1.5px solid #ddd6ca", borderRadius: 7, fontSize: 14, color: "#1e293b", background: "#fff", outline: "none", fontFamily: "inherit", resize: "vertical", minHeight: 100 }} />
                </div>
                <button type="submit" style={{ width: "100%", padding: 13, background: "var(--navy)", color: "#fff", border: "none", borderRadius: 7, fontSize: 15, fontWeight: 600, cursor: "pointer", fontFamily: "inherit", transition: "background .2s" }}
                  onMouseEnter={e => (e.currentTarget.style.background = "var(--gold)")}
                  onMouseLeave={e => (e.currentTarget.style.background = "var(--navy)")}
                >Submit Enquiry</button>
              </form>
            )}
          </div>
        </div>
      </div>
      <style>{`@media(max-width:900px){ .contact-grid{ grid-template-columns:1fr !important; } }`}</style>
    </section>
  );
}

function Field({ label, placeholder, type = "text" }: { label: string; placeholder: string; type?: string }) {
  return (
    <div>
      <label style={{ display: "block", fontSize: 12, fontWeight: 600, color: "var(--navy)", textTransform: "uppercase", letterSpacing: .5, marginBottom: 6 }}>{label}</label>
      <input type={type} placeholder={placeholder} required style={{ width: "100%", padding: "11px 14px", border: "1.5px solid #ddd6ca", borderRadius: 7, fontSize: 14, color: "#1e293b", background: "#fff", outline: "none", fontFamily: "inherit" }} />
    </div>
  );
}
