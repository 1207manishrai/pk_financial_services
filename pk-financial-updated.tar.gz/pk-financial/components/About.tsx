"use client";
export default function About() {
  return (
    <section id="about" style={{ background: "var(--cream)", padding: "80px 24px" }}>
      <div style={{ maxWidth: 1200, margin: "auto", display: "grid", gridTemplateColumns: "1fr 1fr", gap: 60, alignItems: "center" }} className="about-grid">
        <div style={{ position: "relative", height: 400 }}>
          <div style={{ position: "absolute", width: "68%", height: 280, top: 0, left: 0, background: "linear-gradient(135deg,var(--navy),#1a3560)", borderRadius: 12, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 72, boxShadow: "0 20px 60px rgba(0,0,0,.15)" }}>💹</div>
          <div style={{ position: "absolute", width: "55%", height: 230, bottom: 0, right: 0, background: "linear-gradient(135deg,var(--gold),var(--gold2))", borderRadius: 12, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 60, border: "6px solid #fff", boxShadow: "0 20px 60px rgba(0,0,0,.15)" }}>🏦</div>
          <div style={{ position: "absolute", bottom: 60, left: 10, background: "var(--navy)", color: "#fff", padding: "14px 18px", borderRadius: 10, boxShadow: "0 10px 30px rgba(0,0,0,.2)", zIndex: 2 }}>
            <span style={{ fontFamily: "var(--font-playfair,serif)", fontSize: 32, fontWeight: 700, color: "var(--gold)", display: "block" }}>10+</span>
            <span style={{ fontSize: 11, color: "rgba(255,255,255,.7)" }}>Years of Trust</span>
          </div>
        </div>
        <div>
          <h2 style={{ fontFamily: "var(--font-playfair,serif)", fontSize: "clamp(26px,3vw,36px)", fontWeight: 700, color: "var(--navy)", marginBottom: 18, lineHeight: 1.25 }}>
            Welcome to <span style={{ color: "var(--gold)" }}>PK Financial Services</span>
          </h2>
          <p style={{ color: "var(--gray)", lineHeight: 1.8, marginBottom: 14 }}>We are an AMFI-registered Mutual Fund Distributor based in Lucknow with <strong>10+ years of experience</strong>, proudly managing over <strong>₹60 Crore in assets</strong> for <strong>1,000+ happy clients</strong> across Uttar Pradesh.</p>
          <p style={{ color: "var(--gray)", lineHeight: 1.8, marginBottom: 20 }}>Our team brings deep expertise across mutual funds, insurance, retirement planning, and tax optimisation — always putting your interests first.</p>
          <ul style={{ listStyle: "none", margin: "0 0 28px" }}>
            {["AMFI Registered Mutual Fund Distributor","Personalised financial roadmaps for every life stage","Transparent advisory with no hidden charges","Dedicated relationship manager for every client","Regular portfolio review and rebalancing"].map(item => (
              <li key={item} style={{ padding: "10px 0", display: "flex", alignItems: "flex-start", gap: 12, borderBottom: "1px solid #e5e0d8", fontSize: 14, color: "#1e293b" }}>
                <span style={{ background: "var(--gold)", color: "var(--navy)", width: 20, height: 20, borderRadius: "50%", display: "inline-flex", alignItems: "center", justifyContent: "center", fontSize: 11, fontWeight: 700, flexShrink: 0, marginTop: 1 }}>✓</span>
                {item}
              </li>
            ))}
          </ul>
          <a href="#contact" style={{ background: "var(--gold)", color: "var(--navy)", padding: "13px 28px", borderRadius: 5, fontSize: 14, fontWeight: 700, textDecoration: "none", display: "inline-block" }}>Know More →</a>
        </div>
      </div>
      <style>{`@media(max-width:900px){ .about-grid{ grid-template-columns:1fr !important; } }`}</style>
    </section>
  );
}
