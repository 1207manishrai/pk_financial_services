"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";

export default function LoginPage() {
  const router = useRouter();
  const [step, setStep] = useState<"pan" | "otp">("pan");
  const [pan, setPan] = useState("");
  const [mobile, setMobile] = useState("");
  const [otp, setOtp] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [timer, setTimer] = useState(0);

  const startTimer = () => {
    setTimer(60);
    const interval = setInterval(() => setTimer(t => { if (t <= 1) { clearInterval(interval); return 0; } return t - 1; }), 1000);
  };

  const handleRequestOTP = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true); setError("");
    try {
      const res = await fetch("/api/auth/otp", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ pan: pan.toUpperCase(), mobile }) });
      const data = await res.json();
      if (data.success) { setStep("otp"); startTimer(); }
      else setError(data.error || "Failed to send OTP");
    } catch { setError("Network error. Please try again."); }
    setLoading(false);
  };

  const handleVerifyOTP = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true); setError("");
    try {
      const res = await fetch("/api/auth/verify", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ pan: pan.toUpperCase(), otp }) });
      const data = await res.json();
      if (data.success) router.push("/portal/dashboard");
      else setError(data.error || "Invalid OTP");
    } catch { setError("Network error. Please try again."); }
    setLoading(false);
  };

  const inp: React.CSSProperties = { width: "100%", padding: "13px 16px", border: "1.5px solid #ddd", borderRadius: 8, fontSize: 15, outline: "none", fontFamily: "inherit", letterSpacing: 1 };

  return (
    <div style={{ minHeight: "100vh", background: "linear-gradient(135deg,var(--navy) 0%,#1a3560 100%)", display: "flex", alignItems: "center", justifyContent: "center", padding: 24, fontFamily: "'DM Sans',sans-serif" }}>
      <div style={{ width: "100%", maxWidth: 420 }}>
        {/* Logo */}
        <div style={{ textAlign: "center", marginBottom: 32 }}>
          <Link href="/" style={{ textDecoration: "none" }}>
            <div style={{ display: "inline-flex", alignItems: "center", gap: 12, marginBottom: 8 }}>
              <div style={{ width: 52, height: 52, background: "rgba(255,255,255,.1)", borderRadius: 12, display: "flex", alignItems: "center", justifyContent: "center", border: "1px solid rgba(255,255,255,.2)" }}>
                <svg width="30" height="30" viewBox="0 0 28 28" fill="none"><path d="M4 22L10 14L14 18L18 10L24 22H4Z" fill="#c9a84c"/><circle cx="20" cy="7" r="3" fill="#e8c975"/></svg>
              </div>
              <div style={{ textAlign: "left" }}>
                <div style={{ fontFamily: "'Playfair Display',serif", fontSize: 18, fontWeight: 700, color: "#fff" }}>PK Financial Services</div>
                <div style={{ fontSize: 11, color: "var(--gold)", letterSpacing: "1px", textTransform: "uppercase" }}>Client Portal</div>
              </div>
            </div>
          </Link>
        </div>

        {/* Card */}
        <div style={{ background: "#fff", borderRadius: 16, padding: 36, boxShadow: "0 24px 60px rgba(0,0,0,.3)" }}>
          <h2 style={{ fontFamily: "'Playfair Display',serif", fontSize: 24, color: "var(--navy)", marginBottom: 6 }}>
            {step === "pan" ? "Login to Your Portfolio" : "Enter OTP"}
          </h2>
          <p style={{ color: "var(--gray)", fontSize: 13, marginBottom: 28 }}>
            {step === "pan" ? "Enter your PAN and registered mobile number" : `OTP sent to +91 ******${mobile.slice(-4)}`}
          </p>

          {error && <div style={{ background: "#fff0f0", border: "1px solid #ffcccc", borderRadius: 8, padding: "10px 14px", marginBottom: 20, fontSize: 13, color: "#c00" }}>⚠️ {error}</div>}

          {step === "pan" ? (
            <form onSubmit={handleRequestOTP}>
              <div style={{ marginBottom: 16 }}>
                <label style={{ display: "block", fontSize: 12, fontWeight: 600, color: "var(--navy)", textTransform: "uppercase", letterSpacing: ".5px", marginBottom: 6 }}>PAN Number</label>
                <input value={pan} onChange={e => setPan(e.target.value.toUpperCase())} required placeholder="ABCDE1234F" maxLength={10} style={inp} />
                <div style={{ fontSize: 11, color: "var(--gray)", marginTop: 4 }}>e.g. ABCDE1234F</div>
              </div>
              <div style={{ marginBottom: 24 }}>
                <label style={{ display: "block", fontSize: 12, fontWeight: 600, color: "var(--navy)", textTransform: "uppercase", letterSpacing: ".5px", marginBottom: 6 }}>Mobile Number</label>
                <input value={mobile} onChange={e => setMobile(e.target.value)} required type="tel" placeholder="10-digit mobile" maxLength={10} style={inp} />
                <div style={{ fontSize: 11, color: "var(--gray)", marginTop: 4 }}>Registered mobile linked to your mutual fund folios</div>
              </div>
              <button type="submit" disabled={loading} style={{ width: "100%", padding: 14, background: "var(--navy)", color: "#fff", border: "none", borderRadius: 8, fontSize: 15, fontWeight: 700, cursor: loading ? "not-allowed" : "pointer", fontFamily: "inherit", opacity: loading ? .7 : 1 }}>
                {loading ? "Sending OTP..." : "Get OTP →"}
              </button>
            </form>
          ) : (
            <form onSubmit={handleVerifyOTP}>
              <div style={{ marginBottom: 24 }}>
                <label style={{ display: "block", fontSize: 12, fontWeight: 600, color: "var(--navy)", textTransform: "uppercase", letterSpacing: ".5px", marginBottom: 6 }}>Enter OTP</label>
                <input value={otp} onChange={e => setOtp(e.target.value)} required placeholder="6-digit OTP" maxLength={6} style={{ ...inp, textAlign: "center", fontSize: 24, letterSpacing: 8 }} autoFocus />
                <div style={{ fontSize: 11, color: "var(--gray)", marginTop: 4 }}>
                  {timer > 0 ? `Resend OTP in ${timer}s` : <button type="button" onClick={() => { handleRequestOTP({ preventDefault: () => {} } as React.FormEvent); }} style={{ background: "none", border: "none", color: "var(--gold)", cursor: "pointer", fontSize: 12, padding: 0 }}>Resend OTP</button>}
                </div>
              </div>
              <button type="submit" disabled={loading} style={{ width: "100%", padding: 14, background: "#25D366", color: "#fff", border: "none", borderRadius: 8, fontSize: 15, fontWeight: 700, cursor: loading ? "not-allowed" : "pointer", fontFamily: "inherit", opacity: loading ? .7 : 1 }}>
                {loading ? "Verifying..." : "Login to Portfolio ✓"}
              </button>
              <button type="button" onClick={() => { setStep("pan"); setOtp(""); setError(""); }} style={{ width: "100%", marginTop: 10, padding: 12, background: "none", border: "1.5px solid #ddd", borderRadius: 8, fontSize: 14, color: "var(--gray)", cursor: "pointer", fontFamily: "inherit" }}>
                ← Change PAN / Mobile
              </button>
            </form>
          )}

          <div style={{ marginTop: 24, padding: "16px", background: "var(--cream)", borderRadius: 8, fontSize: 12, color: "var(--gray)", lineHeight: 1.6 }}>
            🔒 <strong>Your data is secure.</strong> We fetch your portfolio directly from CAMS & KFintech using your PAN. No data is stored on our servers.
          </div>
        </div>

        <div style={{ textAlign: "center", marginTop: 20, fontSize: 12, color: "rgba(255,255,255,.5)" }}>
          Need help? Call <a href="tel:+918318442129" style={{ color: "var(--gold)", textDecoration: "none" }}>+91 8318442129</a>
        </div>
      </div>
      <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Playfair+Display:wght@400;700&display=swap" rel="stylesheet" />
      <style>{`:root{--navy:#0a1628;--navy2:#112240;--gold:#c9a84c;--cream:#f7f4ef;--gray:#6b7280;} *{box-sizing:border-box;margin:0;padding:0;}`}</style>
    </div>
  );
}
