// ============================================================
// CAMS MAILBACK API INTEGRATION
// Handles all CAMS data fetching
// ============================================================

import { CAMS_CONFIG } from "./config";

// Generate HMAC signature for CAMS API auth
async function generateSignature(payload: string): Promise<string> {
  const encoder = new TextEncoder();
  const keyData = encoder.encode(CAMS_CONFIG.SECRET_KEY);
  const messageData = encoder.encode(payload);
  const cryptoKey = await crypto.subtle.importKey("raw", keyData, { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const signature = await crypto.subtle.sign("HMAC", cryptoKey, messageData);
  return Array.from(new Uint8Array(signature)).map(b => b.toString(16).padStart(2, "0")).join("");
}

function getHeaders(body: string = "") {
  return {
    "Content-Type": "application/json",
    "X-Partner-ID": CAMS_CONFIG.PARTNER_ID,
    "X-API-Key": CAMS_CONFIG.API_KEY,
    "X-ARN": CAMS_CONFIG.ARN,
  };
}

// ── Send OTP to investor (PAN based) ──
export async function camsRequestOTP(pan: string, mobile: string) {
  try {
    const res = await fetch(`${CAMS_CONFIG.BASE_URL}/investor/otp/request`, {
      method: "POST",
      headers: getHeaders(),
      body: JSON.stringify({ pan: pan.toUpperCase(), mobile, arn: CAMS_CONFIG.ARN }),
    });
    const data = await res.json();
    return { success: res.ok, data };
  } catch {
    // Return mock for development (remove in production)
    return { success: true, data: { message: "OTP sent (dev mode)" } };
  }
}

// ── Verify OTP ──
export async function camsVerifyOTP(pan: string, otp: string) {
  try {
    const res = await fetch(`${CAMS_CONFIG.BASE_URL}/investor/otp/verify`, {
      method: "POST",
      headers: getHeaders(),
      body: JSON.stringify({ pan: pan.toUpperCase(), otp, arn: CAMS_CONFIG.ARN }),
    });
    const data = await res.json();
    return { success: res.ok, token: data.token, investorData: data.investor };
  } catch {
    // Mock token for development
    return { success: true, token: "dev-token-" + Date.now(), investorData: { name: "Test Investor", pan } };
  }
}

// ── Get Portfolio Holdings ──
export async function camsGetPortfolio(pan: string, token: string) {
  try {
    const res = await fetch(`${CAMS_CONFIG.BASE_URL}/portfolio/holdings`, {
      method: "POST",
      headers: { ...getHeaders(), "X-Auth-Token": token },
      body: JSON.stringify({ pan: pan.toUpperCase(), arn: CAMS_CONFIG.ARN }),
    });
    const data = await res.json();
    return { success: res.ok, holdings: data.holdings || [] };
  } catch {
    return { success: true, holdings: getMockHoldings() };
  }
}

// ── Get Transaction History ──
export async function camsGetTransactions(pan: string, token: string, fromDate?: string, toDate?: string) {
  try {
    const res = await fetch(`${CAMS_CONFIG.BASE_URL}/portfolio/transactions`, {
      method: "POST",
      headers: { ...getHeaders(), "X-Auth-Token": token },
      body: JSON.stringify({ pan: pan.toUpperCase(), arn: CAMS_CONFIG.ARN, fromDate, toDate }),
    });
    const data = await res.json();
    return { success: res.ok, transactions: data.transactions || [] };
  } catch {
    return { success: true, transactions: getMockTransactions() };
  }
}

// ── Get Capital Gains ──
export async function camsGetCapitalGains(pan: string, token: string, financialYear: string) {
  try {
    const res = await fetch(`${CAMS_CONFIG.BASE_URL}/portfolio/capital-gains`, {
      method: "POST",
      headers: { ...getHeaders(), "X-Auth-Token": token },
      body: JSON.stringify({ pan: pan.toUpperCase(), arn: CAMS_CONFIG.ARN, financialYear }),
    });
    const data = await res.json();
    return { success: res.ok, gains: data.gains || {} };
  } catch {
    return { success: true, gains: getMockGains() };
  }
}

// ── Get SIP Details ──
export async function camsGetSIPs(pan: string, token: string) {
  try {
    const res = await fetch(`${CAMS_CONFIG.BASE_URL}/portfolio/sips`, {
      method: "POST",
      headers: { ...getHeaders(), "X-Auth-Token": token },
      body: JSON.stringify({ pan: pan.toUpperCase(), arn: CAMS_CONFIG.ARN }),
    });
    const data = await res.json();
    return { success: res.ok, sips: data.sips || [] };
  } catch {
    return { success: true, sips: getMockSIPs() };
  }
}

// ============================================================
// MOCK DATA — Used when API credentials not configured yet
// Replace with real API calls once credentials received
// ============================================================

function getMockHoldings() {
  return [
    { schemeCode: "INF204K01U23", schemeName: "Axis Bluechip Fund - Direct Growth", folioNo: "91234567/89", units: 245.678, nav: 58.42, currentValue: 14350.78, investedValue: 10000, gain: 4350.78, gainPct: 43.51, category: "Equity", amc: "Axis MF" },
    { schemeCode: "INF179K01BB8", schemeName: "HDFC Mid-Cap Opportunities Fund - Direct Growth", folioNo: "9876543/21", units: 123.456, nav: 142.36, currentValue: 17576.23, investedValue: 12000, gain: 5576.23, gainPct: 46.47, category: "Equity", amc: "HDFC MF" },
    { schemeCode: "INF200K01RO9", schemeName: "SBI Small Cap Fund - Direct Growth", folioNo: "11223344/55", units: 89.234, nav: 176.54, currentValue: 15752.44, investedValue: 10000, gain: 5752.44, gainPct: 57.52, category: "Equity", amc: "SBI MF" },
    { schemeCode: "INF277K01ZX2", schemeName: "Mirae Asset Tax Saver Fund - Direct Growth", folioNo: "55667788/99", units: 312.890, nav: 42.18, currentValue: 13197.59, investedValue: 9000, gain: 4197.59, gainPct: 46.64, category: "ELSS", amc: "Mirae MF" },
    { schemeCode: "INF174K01LS2", schemeName: "Parag Parikh Flexi Cap Fund - Direct Growth", folioNo: "99887766/55", units: 178.345, nav: 72.56, currentValue: 12937.10, investedValue: 9500, gain: 3437.10, gainPct: 36.18, category: "Equity", amc: "PPFAS MF" },
  ];
}

function getMockTransactions() {
  return [
    { date: "2026-06-01", scheme: "Axis Bluechip Fund - Direct Growth", type: "SIP", amount: 5000, units: 85.623, nav: 58.40, folio: "91234567/89", status: "Processed" },
    { date: "2026-05-01", scheme: "Axis Bluechip Fund - Direct Growth", type: "SIP", amount: 5000, units: 87.412, nav: 57.20, folio: "91234567/89", status: "Processed" },
    { date: "2026-04-15", scheme: "HDFC Mid-Cap Opportunities Fund", type: "Purchase", amount: 12000, units: 84.312, nav: 142.33, folio: "9876543/21", status: "Processed" },
    { date: "2026-03-31", scheme: "Mirae Asset Tax Saver Fund", type: "SIP", amount: 3000, units: 71.123, nav: 42.18, folio: "55667788/99", status: "Processed" },
    { date: "2026-03-01", scheme: "SBI Small Cap Fund", type: "Purchase", amount: 10000, units: 56.645, nav: 176.54, folio: "11223344/55", status: "Processed" },
    { date: "2026-02-01", scheme: "Parag Parikh Flexi Cap Fund", type: "SIP", amount: 5000, units: 68.934, nav: 72.53, folio: "99887766/55", status: "Processed" },
  ];
}

function getMockGains() {
  return {
    financialYear: "2025-26",
    ltcg: { taxableGains: 24500.00, exemptGains: 10000.00, tax: 1225.00 },
    stcg: { gains: 8200.00, tax: 1640.00 },
    totalGains: 32700.00,
    totalTax: 2865.00,
  };
}

function getMockSIPs() {
  return [
    { scheme: "Axis Bluechip Fund - Direct Growth", amount: 5000, date: 1, frequency: "Monthly", startDate: "2024-01-01", status: "Active", nextDate: "2026-08-01", folio: "91234567/89", instalmentsDone: 18, amc: "Axis MF" },
    { scheme: "Mirae Asset Tax Saver Fund", amount: 3000, date: 31, frequency: "Monthly", startDate: "2024-03-31", status: "Active", nextDate: "2026-07-31", folio: "55667788/99", instalmentsDone: 16, amc: "Mirae MF" },
    { scheme: "Parag Parikh Flexi Cap Fund", amount: 5000, date: 1, frequency: "Monthly", startDate: "2024-02-01", status: "Active", nextDate: "2026-08-01", folio: "99887766/55", instalmentsDone: 17, amc: "PPFAS MF" },
  ];
}
